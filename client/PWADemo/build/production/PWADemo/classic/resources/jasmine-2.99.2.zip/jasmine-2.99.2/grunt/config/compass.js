module.exports = {
  jasmine: {
    options: {
      cssDir: 'lib/jasmine-core/',
      sassDir: 'src/html',
      outputStyle: 'compact',
      noLineComments: true,
      bundleExec: true
    }
  }
};
